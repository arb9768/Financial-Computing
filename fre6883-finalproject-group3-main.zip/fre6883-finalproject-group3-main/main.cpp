#include <iostream>
#include <iomanip>
#include <vector>
#include <thread>
#include <algorithm>
#include <fstream>
#include <stdexcept>
#include <sstream>
#include <map>
#include "Menu.h"

using namespace std;
using namespace fre;

int main()
{
    MenuCommands();
    return 0;
}